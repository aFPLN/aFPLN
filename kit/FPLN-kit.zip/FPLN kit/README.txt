FPLN KIT  (Flight Plan 0.9.0 beta 1 · 12 Nov 2026)
=================================
Everything for FPLN in one place.

1 Install FPLN\
   Install FPLN.cmd ............ opens the install page in Edge; click Install FPLN
   FPLN keep awake.cmd ......... stops Windows sleeping while plugged in (for overnight alarms); asks Y/N first
   FPLN undo keep awake.cmd .... puts your sleep settings back
   FPLN (web link) ............. opens FPLN in your browser

2 Share\
   banner.png .................. the FPLN picture to text or post
   email-picture.png ........... the picture used in the email banner
   badge.png, badge-gold.png ... install badges
   link-preview.png ............ what a pasted link looks like in chats
   Email banner.html ........... open it, click Copy banner, paste into any email (stays clickable)
   message.txt ................. ready-made text to send people

3 Links\
   FPLN app, Install page, Share page, Download machine
   (edit the install page from your private FPLN Command Center)

4 Screenshots\
   FPLN on a laptop, on a phone, and the Flight plan

Install link to give people:  https://afpln.github.io/aFPLN/get
Keep CUI out of FPLN. Your data stays on your own device.
