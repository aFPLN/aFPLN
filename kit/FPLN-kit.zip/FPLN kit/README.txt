FPLN KIT  (Flight Plan, beta 1)
=================================
Everything for FPLN in one place.

1 Install FPLN\
   Install FPLN.cmd ............ opens the install page in Edge; click Install FPLN
   FPLN keep awake.cmd ......... stops Windows sleeping while plugged in (for overnight alarms); asks Y/N first
   FPLN undo keep awake.cmd .... puts your sleep settings back
   FPLN (web link) ............. opens FPLN in your browser

2 Share\
   banner.png .................. the big FPLN banner
   badge.png, badge-gold.png ... install badges
   qr-code.png ................. scan to install (phones)
   link-preview.png ............ what a pasted link looks like in chats
   email-banners.html .......... open it, copy a banner, paste into an email (stays clickable)
   message.txt ................. ready-made text to send people

3 Links\
   FPLN app, Install page, Share page, Page builder, Download machine,
   and "Edit site settings (GitHub)" for publishing page-builder changes

4 Screenshots\
   FPLN on a laptop and on a phone

Install link to give people:  https://braveheart30.github.io/FPLN-/get
Keep CUI out of FPLN. Your data stays on your own device.
