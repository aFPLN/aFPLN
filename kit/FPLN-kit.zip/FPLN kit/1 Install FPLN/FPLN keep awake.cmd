@echo off
title FPLN - keep this laptop awake for alarms
echo.
echo   FPLN: keep this laptop awake for alarms and minute calls
echo   --------------------------------------------------------
echo   This changes YOUR power settings, only while PLUGGED IN:
echo     - Turn off the screen after 5 minutes
echo     - Never go to sleep on its own
echo   Battery settings are not touched. Undo any time with
echo   "FPLN undo keep awake.cmd".
echo.
choice /c YN /m "  Make these changes"
if errorlevel 2 goto cancel

set "FAIL="
powercfg /change monitor-timeout-ac 5 || set "FAIL=1"
powercfg /change standby-timeout-ac 0 || set "FAIL=1"

echo.
choice /c YN /m "  Also keep running when the lid is CLOSED (plugged in only)"
if errorlevel 2 goto done
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0 || set "FAIL=1"
powercfg /setactive SCHEME_CURRENT || set "FAIL=1"

:done
echo.
if defined FAIL (
  echo   Some settings could not be changed. Your laptop's IT policy probably
  echo   controls them. Use FPLN's "Back up alarms to my phone" instead.
) else (
  echo   Done. While plugged in, the screen turns off after 5 minutes and the
  echo   laptop stays awake, so FPLN can ring. Leave FPLN open and the volume up.
  echo   If IT resets these later, just run this file again.
)
echo.
pause
exit /b

:cancel
echo.
echo   Nothing was changed.
echo.
pause
