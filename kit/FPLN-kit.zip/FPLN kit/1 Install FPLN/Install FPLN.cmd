@echo off
rem FPLN (beta) - opens the install page in Microsoft Edge. Click "Install FPLN" there; FPLN then opens in its own window.
rem Nothing is changed on this computer by this file. Updates arrive by themselves.
set "URL=https://braveheart30.github.io/FPLN-/download/?from=zip"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" "%URL%"
) else (
  start "" "%URL%"
)
